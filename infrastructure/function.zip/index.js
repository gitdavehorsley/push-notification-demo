const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { DynamoDBDocumentClient, PutCommand, GetCommand, DeleteCommand, UpdateCommand } = require("@aws-sdk/lib-dynamodb");
const { SNSClient, PublishCommand } = require("@aws-sdk/client-sns");

const ddbClient = new DynamoDBClient({ region: process.env.AWS_REGION });
const docClient = DynamoDBDocumentClient.from(ddbClient);
const snsClient = new SNSClient({ region: process.env.AWS_REGION });

const SUBSCRIBERS_TABLE = process.env.SUBSCRIBERS_TABLE;
const VERIFICATION_CODES_TABLE = process.env.VERIFICATION_CODES_TABLE;
const OTP_EXPIRATION_MINUTES = 5;
const MAX_OTP_ATTEMPTS = 3;

function generateOTP() {
  return Math.floor(1000 + Math.random() * 9000).toString();
}

async function sendOTP(phoneNumber) {
  const otp = generateOTP();
  const expirationTime = Math.floor(Date.now() / 1000) + (OTP_EXPIRATION_MINUTES * 60);
  
  await docClient.send(new PutCommand({
    TableName: VERIFICATION_CODES_TABLE,
    Item: {
      phone_number: phoneNumber,
      otp_code: otp,
      expiration_time: expirationTime,
      attempts: 0
    }
  }));

  await snsClient.send(new PublishCommand({
    Message: `Your verification code is: ${otp}. It will expire in ${OTP_EXPIRATION_MINUTES} minutes.`,
    PhoneNumber: phoneNumber
  }));

  return { success: true, message: 'OTP sent successfully' };
}

async function verifyOTP(phoneNumber, otpCode, deviceId) {
  const verificationRecord = await docClient.send(new GetCommand({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { phone_number: phoneNumber }
  }));

  if (!verificationRecord.Item) {
    return { success: false, message: 'No verification code found' };
  }

  const record = verificationRecord.Item;
  const currentTime = Math.floor(Date.now() / 1000);

  if (currentTime > record.expiration_time) {
    await docClient.send(new DeleteCommand({
      TableName: VERIFICATION_CODES_TABLE,
      Key: { phone_number: phoneNumber }
    }));
    return { success: false, message: 'Verification code expired' };
  }

  if (record.attempts >= MAX_OTP_ATTEMPTS) {
    await docClient.send(new DeleteCommand({
      TableName: VERIFICATION_CODES_TABLE,
      Key: { phone_number: phoneNumber }
    }));
    return { success: false, message: 'Maximum attempts exceeded' };
  }

  if (record.otp_code !== otpCode) {
    await docClient.send(new UpdateCommand({
      TableName: VERIFICATION_CODES_TABLE,
      Key: { phone_number: phoneNumber },
      UpdateExpression: 'SET attempts = attempts + :inc',
      ExpressionAttributeValues: { ':inc': 1 }
    }));
    return { success: false, message: 'Invalid verification code' };
  }

  // OTP is valid, store subscriber info
  await docClient.send(new PutCommand({
    TableName: SUBSCRIBERS_TABLE,
    Item: {
      phone_number: phoneNumber,
      device_id: deviceId,
      subscription_date: new Date().toISOString(),
      verified: true
    }
  }));

  // Delete verification record
  await docClient.send(new DeleteCommand({
    TableName: VERIFICATION_CODES_TABLE,
    Key: { phone_number: phoneNumber }
  }));

  return { success: true, message: 'Phone number verified successfully' };
}

exports.handler = async (event) => {
  try {
    const { action, phone_number, device_id, otp_code } = event;
    
    if (!phone_number || !/^\+?[1-9]\d{1,14}$/.test(phone_number)) {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: 'Invalid phone number format' })
      };
    }

    let result;
    if (action === 'send_otp') {
      result = await sendOTP(phone_number);
    } else if (action === 'verify_otp') {
      if (!device_id || !otp_code) {
        return {
          statusCode: 400,
          body: JSON.stringify({ success: false, message: 'Missing device_id or otp_code' })
        };
      }
      result = await verifyOTP(phone_number, otp_code, device_id);
    } else {
      return {
        statusCode: 400,
        body: JSON.stringify({ success: false, message: 'Invalid action' })
      };
    }

    return {
      statusCode: result.success ? 200 : 400,
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ success: false, message: 'Internal server error' })
    };
  }
};
